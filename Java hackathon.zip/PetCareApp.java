import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

/* ===================== APPLICATION ===================== */
public class PetCareApp {
    private static final String DATA_FILE = "gets.txt";
    private static final String LOG_FILE = "visits.log";

    private static final ArrayList<PetPatient> patients = new ArrayList<>();
    private static double totalRevenue = 0.0;
    private static Scanner in = new Scanner(System.in);

    /** Thrown when the input stream ends (e.g. piped input) so the menu can exit cleanly. */
    private static class InputEnded extends RuntimeException { }

    public static void main(String[] args) {
        loadPatients();
        loadRevenueFromLog();
        System.out.println("PetCare - Veterinary Clinic Records and Billing System");

        boolean running = true;
        while (running) {
            printMenu();
            try {
                int choice = readInt("Enter choice: ");
                switch (choice) {
                    case 1: addRecord(); break;
                    case 2: displayAll(); break;
                    case 3: searchOrDeleteById(); break;
                    case 4: searchByOwner(); break;
                    case 5: processVisit(); break;
                    case 6: listVaccinationDue(); break;
                    case 7: showStatistics(); break;
                    case 8: sortById(); break;
                    case 9: running = false; break;
                    default: System.out.println("Invalid choice. Enter a number from 1 to 9.");
                }
            } catch (InputEnded e) {
                System.out.println("\nInput ended - saving and exiting.");
                running = false;
            }
        }
        savePatients();
        System.out.println("Data saved to " + DATA_FILE + ". Goodbye!");
    }

    private static void printMenu() {
        System.out.println("\n========= PETCARE MENU =========");
        System.out.println("1. Add new record (Standard / Exotic)");
        System.out.println("2. Display all records");
        System.out.println("3. Search / delete by ID");
        System.out.println("4. Search by owner name");
        System.out.println("5. Process client visit (billing)");
        System.out.println("6. List pets due for vaccination");
        System.out.println("7. Clinic statistics");
        System.out.println("8. Sort records by ID");
        System.out.println("9. Save and exit");
    }

    /* ---------- input helpers ---------- */
    private static String readLine(String prompt) {
        System.out.print(prompt);
        if (!in.hasNextLine()) throw new InputEnded();
        return in.nextLine().trim().replace(",", " "); // commas would break the CSV file
    }

    private static int readInt(String prompt) {
        while (true) {
            String s = readLine(prompt);
            try {
                return Integer.parseInt(s);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a whole number.");
            }
        }
    }

    private static double readDouble(String prompt) {
        while (true) {
            String s = readLine(prompt);
            try {
                return Double.parseDouble(s);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number.");
            }
        }
    }

    private static int readIntInRange(String prompt, int lo, int hi) {
        while (true) {
            int v = readInt(prompt);
            if (v >= lo && v <= hi) return v;
            System.out.println("Value must be between " + lo + " and " + hi + ".");
        }
    }

    /* ---------- lookup ---------- */
    private static PetPatient findById(int id) throws PetNotFoundException {
        for (int i = 0; i < patients.size(); i++) {
            if (patients.get(i).getPetId() == id) return patients.get(i);
        }
        throw new PetNotFoundException("No patient found with ID " + id + ".");
    }

    private static boolean idExists(int id) {
        for (int i = 0; i < patients.size(); i++) {
            if (patients.get(i).getPetId() == id) return true;
        }
        return false;
    }

    /* ---------- 1. add ---------- */
    private static void addRecord() {
        int type = readIntInRange("Type (1 = Standard, 2 = Exotic): ", 1, 2);
        int id = readInt("Pet ID (positive integer): ");
        if (id <= 0) {
            System.out.println("ID must be positive. Record not added.");
            return;
        }
        if (idExists(id)) {
            System.out.println("A patient with ID " + id + " already exists. Record not added.");
            return;
        }
        String name = readLine("Pet name: ");
        String owner = readLine("Owner name: ");
        double weight = readDouble("Weight in kg (0 < w <= 120): ");

        try {
            if (type == 1) {
                patients.add(new PetPatient(id, name, owner, weight));
            } else {
                String species = readLine("Species: ");
                String qText = readLine("Quarantine days (positive integer): ");
                int qDays;
                try {
                    qDays = Integer.parseInt(qText);
                } catch (NumberFormatException nfe) {
                    throw new QuarantineRequiredException(
                        "Exotic pets need isolation: '" + qText + "' is not a positive integer.");
                }
                String origin = readLine("Country of origin: ");
                double temp = readDouble("Optimal temperature (C): ");
                String permit = readLine("Permit status: ");
                String diet = readLine("Diet type: ");
                int danger = readIntInRange("Danger scale (1-" + ExoticPet.maxDangerScale + "): ",
                        1, ExoticPet.maxDangerScale);
                patients.add(new ExoticPet(id, name, owner, weight, 0, species, qDays,
                        origin, temp, permit, diet, danger));
            }
            System.out.println("Record added successfully.");
        } catch (InvalidWeightException e) {
            System.out.println("WARNING: " + e.getMessage());
        } catch (QuarantineRequiredException e) {
            System.out.println("WARNING: " + e.getMessage());
        } finally {
            System.out.println("(Registered patients: " + PetPatient.patientCount + ")");
        }
    }

    /* ---------- 2. display ---------- */
    private static void displayAll() {
        if (patients.isEmpty()) {
            System.out.println("No records registered.");
            return;
        }
        for (int i = 0; i < patients.size(); i++) {
            patients.get(i).display();          // dynamic polymorphism
        }
    }

    /* ---------- 3. search / delete ---------- */
    private static void searchOrDeleteById() {
        int id = readInt("Enter pet ID: ");
        try {
            PetPatient p = findById(id);
            p.display();
            String answer = readLine("Delete this record? (y/n): ");
            if (answer.equalsIgnoreCase("y")) {
                patients.remove(p);
                p.onRemoved();
                System.out.println("Record deleted.");
            }
        } catch (PetNotFoundException e) {
            System.out.println("WARNING: " + e.getMessage());
        } finally {
            System.out.println("(Search finished)");
        }
    }

    /* ---------- 4. owner search ---------- */
    private static void searchByOwner() {
        String owner = readLine("Enter owner name: ");
        try {
            boolean found = false;
            for (int i = 0; i < patients.size(); i++) {
                PetPatient p = patients.get(i);
                if (p.getOwnerName().equalsIgnoreCase(owner)) {
                    found = true;
                    String status = p.isVaccinationDue()
                            ? "VACCINATION DUE"
                            : "Not due (" + (PetPatient.VACCINATION_INTERVAL
                                - p.getVisitCount() % PetPatient.VACCINATION_INTERVAL)
                              + " visit(s) to go)";
                    String kind = (p instanceof ExoticPet)
                            ? " [Exotic: " + ((ExoticPet) p).getSpecies() + "]" : "";
                    System.out.println("Pet: " + p.getName() + kind + " | Vaccination: " + status);
                }
            }
            if (!found) {
                throw new PetNotFoundException("No records found for owner '" + owner + "'.");
            }
        } catch (PetNotFoundException e) {
            System.out.println("WARNING: " + e.getMessage());
        } finally {
            System.out.println("(Owner search finished)");
        }
    }

    /* ---------- 5. billing ---------- */
    private static void processVisit() {
        int id = readInt("Enter pet ID for visit: ");
        try {
            PetPatient p = findById(id);
            double oldWeight = p.getWeight();

            p.incrementVisit();   // visit counter first, so every 6th visit adds the vaccine fee

            String w = readLine("Update weight? Enter new kg or press Enter to keep (" + oldWeight + "): ");
            if (!w.isEmpty()) {
                try {
                    p.setWeight(Double.parseDouble(w));
                } catch (NumberFormatException nfe) {
                    System.out.println("WARNING: '" + w + "' is not a number. Weight unchanged.");
                } catch (InvalidWeightException iwe) {
                    System.out.println("WARNING: " + iwe.getMessage() + " Weight unchanged.");
                }
            }

            printInvoice(p);

            String paid = readLine("Confirm payment received? (y/n): ");
            if (paid.equalsIgnoreCase("y")) {
                double bill = p.calculateTreatmentCost();
                totalRevenue += bill;
                logVisit(p, bill);
                System.out.println("Payment recorded. Visit logged.");
            } else {
                // visit cancelled: roll back counter and weight
                p.setVisitCount(p.getVisitCount() - 1);
                try { p.setWeight(oldWeight); } catch (InvalidWeightException ignored) { }
                System.out.println("Payment not confirmed. Visit cancelled.");
            }
        } catch (PetNotFoundException e) {
            System.out.println("WARNING: " + e.getMessage());
        } finally {
            System.out.println("(Billing workflow finished)");
        }
    }

    private static void printInvoice(PetPatient p) {
        System.out.println("\n------------- INVOICE -------------");
        System.out.println("Patient : " + p.getName() + " (ID " + p.getPetId() + ")");
        System.out.println("Owner   : " + p.getOwnerName());
        System.out.println("Visit # : " + p.getVisitCount());
        line("Consultation fee", PetPatient.consultationFee);
        line(String.format("Medicine (%.2f kg x %.1f)", p.getWeight(), PetPatient.medicineRatePerKg),
                p.getWeight() * PetPatient.medicineRatePerKg);
        if (p.isVaccinationDue()) {
            line("Vaccination fee", PetPatient.vaccinationFee);
        }
        if (p instanceof ExoticPet) {
            ExoticPet e = (ExoticPet) p;
            line("Specialist fee", ExoticPet.specialistFee);
            line(String.format("Quarantine (%d d x %.1f)", e.getQuarantineDays(),
                    ExoticPet.quarantineChargePerDay),
                    e.getQuarantineDays() * ExoticPet.quarantineChargePerDay);
        }
        line("TOTAL", p.calculateTreatmentCost());
        System.out.println("-----------------------------------");
    }

    private static void line(String label, double amount) {
        System.out.printf("%-28s: %10.2f%n", label, amount);
    }

    private static void logVisit(PetPatient p, double bill) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(LOG_FILE, true))) {
            bw.write(p.getPetId() + "," + p.getName() + "," + String.format("%.2f", bill));
            bw.newLine();
        } catch (IOException e) {
            System.out.println("WARNING: could not write to " + LOG_FILE + ": " + e.getMessage());
        }
    }

    /* ---------- 6. vaccination list ---------- */
    private static void listVaccinationDue() {
        boolean any = false;
        for (int i = 0; i < patients.size(); i++) {
            if (patients.get(i).isVaccinationDue()) {
                patients.get(i).display();
                any = true;
            }
        }
        if (!any) System.out.println("No patients are currently due for vaccination.");
    }

    /* ---------- 7. statistics ---------- */
    private static void showStatistics() {
        System.out.printf("Total clinic revenue: Rs. %.2f%n", totalRevenue);
        try {
            if (patients.isEmpty()) {
                throw new PetNotFoundException("No patients registered, so there is no heaviest pet.");
            }
            PetPatient heaviest = patients.get(0);
            for (int i = 1; i < patients.size(); i++) {
                if (patients.get(i).getWeight() > heaviest.getWeight()) {
                    heaviest = patients.get(i);
                }
            }
            System.out.println("Heaviest patient:");
            heaviest.display();
        } catch (PetNotFoundException e) {
            System.out.println("WARNING: " + e.getMessage());
        }
    }

    /* ---------- 8. manual bubble sort (no Collections.sort, no arrays) ---------- */
    private static void sortById() {
        int n = patients.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (patients.get(j).getPetId() > patients.get(j + 1).getPetId()) {
                    PetPatient temp = patients.get(j);
                    patients.set(j, patients.get(j + 1));
                    patients.set(j + 1, temp);
                }
            }
        }
        System.out.println("Records sorted by ID.");
        displayAll();
    }

    /* ---------- file persistence ---------- */
    private static void savePatients() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(DATA_FILE))) {
            for (int i = 0; i < patients.size(); i++) {
                PetPatient p = patients.get(i);
                String base = p.getPetId() + "," + p.getName() + "," + p.getOwnerName() + ","
                        + p.getWeight() + "," + p.getVisitCount();
                if (p instanceof ExoticPet) {
                    ExoticPet e = (ExoticPet) p;
                    bw.write("EXOTIC," + base + "," + e.getSpecies() + "," + e.getQuarantineDays()
                            + "," + e.getOriginCountry() + "," + e.getOptimalTemp()
                            + "," + e.getPermitStatus() + "," + e.getDietType()
                            + "," + e.getDangerScale());
                } else {
                    bw.write("STANDARD," + base);
                }
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("WARNING: could not save data: " + e.getMessage());
        }
    }

    private static void loadPatients() {
        File f = new File(DATA_FILE);
        if (!f.exists()) {
            System.out.println("No data file found - starting with an empty record list.");
            return;
        }
        int loaded = 0, skipped = 0;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            int lineNo = 0;
            while ((line = br.readLine()) != null) {
                lineNo++;
                if (line.trim().isEmpty()) continue;
                try {
                    String[] t = line.split(",", -1);
                    int id = Integer.parseInt(t[1].trim());
                    if (id <= 0 || idExists(id)) {
                        throw new IllegalArgumentException("bad or duplicate ID");
                    }
                    String name = t[2].trim();
                    String owner = t[3].trim();
                    double weight = Double.parseDouble(t[4].trim());
                    int visits = Integer.parseInt(t[5].trim());

                    if (t[0].trim().equals("STANDARD")) {
                        patients.add(new PetPatient(id, name, owner, weight, visits));
                    } else if (t[0].trim().equals("EXOTIC")) {
                        patients.add(new ExoticPet(id, name, owner, weight, visits,
                                t[6].trim(), Integer.parseInt(t[7].trim()), t[8].trim(),
                                Double.parseDouble(t[9].trim()), t[10].trim(), t[11].trim(),
                                Integer.parseInt(t[12].trim())));
                    } else {
                        throw new IllegalArgumentException("unknown type token");
                    }
                    loaded++;
                } catch (ArrayIndexOutOfBoundsException | IllegalArgumentException
                         | InvalidWeightException | QuarantineRequiredException e) {
                    skipped++;
                    System.out.println("Skipped damaged line " + lineNo + " (" + e.getMessage() + ")");
                }
            }
        } catch (IOException e) {
            System.out.println("WARNING: could not read " + DATA_FILE + ": " + e.getMessage());
        }
        System.out.println("Loaded " + loaded + " record(s), skipped " + skipped + ".");
    }

    // Rebuild the running revenue total from visits.log so it survives restarts
    private static void loadRevenueFromLog() {
        File f = new File(LOG_FILE);
        if (!f.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                try {
                    String[] t = line.split(",");
                    totalRevenue += Double.parseDouble(t[t.length - 1].trim());
                } catch (NumberFormatException e) {
                    // ignore damaged log line
                }
            }
        } catch (IOException e) {
            System.out.println("WARNING: could not read " + LOG_FILE + ": " + e.getMessage());
        }
    }
}

/* ===================== INTERFACE ===================== */
interface Treatable {
    double calculateTreatmentCost();
}

/* ===================== CUSTOM CHECKED EXCEPTIONS ===================== */
class InvalidWeightException extends Exception {
    public InvalidWeightException(String message) { super(message); }
}

class PetNotFoundException extends Exception {
    public PetNotFoundException(String message) { super(message); }
}

class QuarantineRequiredException extends Exception {
    public QuarantineRequiredException(String message) { super(message); }
}

/* ===================== PARENT CLASS ===================== */
class PetPatient implements Treatable {
    // instance variables (private -> encapsulation)
    private int petId;
    private String name;
    private String ownerName;
    private double weight;
    private int visitCount;

    // static variables
    public static double consultationFee = 500.0;
    public static double medicineRatePerKg = 15.0;
    public static double vaccinationFee = 450.0;
    public static int patientCount = 0;
    public static final int VACCINATION_INTERVAL = 6;

    // default constructor
    public PetPatient() {
        this.petId = 0;
        this.name = "Unknown";
        this.ownerName = "Unknown";
        this.weight = 1.0;
        this.visitCount = 0;
        patientCount++;
    }

    // overloaded constructor -> chains to the full constructor with this()
    public PetPatient(int petId, String name, String ownerName, double weight)
            throws InvalidWeightException {
        this(petId, name, ownerName, weight, 0);
    }

    // fully parametric constructor
    public PetPatient(int petId, String name, String ownerName, double weight, int visitCount)
            throws InvalidWeightException {
        checkWeight(weight);
        if (visitCount < 0) {
            throw new IllegalArgumentException("Visit count cannot be negative");
        }
        this.petId = petId;
        this.name = name;
        this.ownerName = ownerName;
        this.weight = weight;
        this.visitCount = visitCount;
        patientCount++;
    }

    private static void checkWeight(double w) throws InvalidWeightException {
        if (Double.isNaN(w) || w <= 0 || w > 120) {
            throw new InvalidWeightException(
                "Weight " + w + " kg is invalid. Allowed range: above 0 and up to 120 kg.");
        }
    }

    // accessors / mutators
    public int getPetId() { return petId; }
    public String getName() { return name; }
    public String getOwnerName() { return ownerName; }
    public double getWeight() { return weight; }
    public int getVisitCount() { return visitCount; }

    public void setName(String name) { this.name = name; }
    public void setOwnerName(String ownerName) { this.ownerName = ownerName; }
    public void setVisitCount(int visitCount) { this.visitCount = visitCount; }

    public void setWeight(double weight) throws InvalidWeightException {
        checkWeight(weight);
        this.weight = weight;
    }

    public void incrementVisit() { visitCount++; }

    // vaccination is due on every 6th visit
    public boolean isVaccinationDue() {
        return visitCount > 0 && visitCount % VACCINATION_INTERVAL == 0;
    }

    @Override
    public double calculateTreatmentCost() {
        double cost = consultationFee + (weight * medicineRatePerKg);
        if (isVaccinationDue()) {
            cost += vaccinationFee;
        }
        return cost;
    }

    public void display() {
        System.out.printf("ID: %d | Name: %s | Owner: %s | Weight: %.2f kg | Visits: %d | Vaccination due: %s%n",
                petId, name, ownerName, weight, visitCount, isVaccinationDue() ? "YES" : "no");
    }

    // called when the record is deleted (overridden in the child)
    public void onRemoved() { patientCount--; }
}

/* ===================== CHILD CLASS ===================== */
class ExoticPet extends PetPatient {
    // 2 mandatory + 5 custom private instance fields (7 here + 5 inherited = 12 total)
    private String species;
    private int quarantineDays;
    private String originCountry;
    private double optimalTemp;
    private String permitStatus;
    private String dietType;
    private int dangerScale;

    // static variables (5 in this class)
    public static double specialistFee = 500.0;
    public static double quarantineChargePerDay = 200.0;
    public static int exoticCount = 0;
    public static int maxDangerScale = 5;
    public static String currency = "Rs.";

    // default constructor (implicit super())
    public ExoticPet() {
        this.species = "Unknown";
        this.quarantineDays = 1;
        this.originCountry = "Unknown";
        this.optimalTemp = 25.0;
        this.permitStatus = "Pending";
        this.dietType = "Unknown";
        this.dangerScale = 1;
        exoticCount++;
    }

    // short constructor -> chains with this()
    public ExoticPet(int id, String name, String owner, double weight,
                     String species, int quarantineDays)
            throws InvalidWeightException, QuarantineRequiredException {
        this(id, name, owner, weight, 0, species, quarantineDays,
             "Unknown", 25.0, "Pending", "Unknown", 1);
    }

    // full constructor -> passes parent data up with super()
    public ExoticPet(int id, String name, String owner, double weight, int visits,
                     String species, int quarantineDays, String originCountry,
                     double optimalTemp, String permitStatus, String dietType, int dangerScale)
            throws InvalidWeightException, QuarantineRequiredException {
        super(id, name, owner, weight, visits);
        checkQuarantine(quarantineDays);
        this.species = species;
        this.quarantineDays = quarantineDays;
        this.originCountry = originCountry;
        this.optimalTemp = optimalTemp;
        this.permitStatus = permitStatus;
        this.dietType = dietType;
        this.dangerScale = dangerScale;
        exoticCount++;
    }

    private static void checkQuarantine(int days) throws QuarantineRequiredException {
        if (days <= 0) {
            throw new QuarantineRequiredException(
                "Exotic pets need isolation: quarantineDays must be a positive integer.");
        }
    }

    public String getSpecies() { return species; }
    public int getQuarantineDays() { return quarantineDays; }
    public String getOriginCountry() { return originCountry; }
    public double getOptimalTemp() { return optimalTemp; }
    public String getPermitStatus() { return permitStatus; }
    public String getDietType() { return dietType; }
    public int getDangerScale() { return dangerScale; }

    public void setQuarantineDays(int days) throws QuarantineRequiredException {
        checkQuarantine(days);
        this.quarantineDays = days;
    }

    @Override
    public double calculateTreatmentCost() {
        return super.calculateTreatmentCost() + specialistFee
                + (quarantineDays * quarantineChargePerDay);
    }

    @Override
    public void display() {
        super.display();
        System.out.printf("   [EXOTIC] Species: %s | Origin: %s | Quarantine: %d days | Temp: %.1f C | "
                        + "Permit: %s | Diet: %s | Danger: %d/%d%n",
                species, originCountry, quarantineDays, optimalTemp,
                permitStatus, dietType, dangerScale, maxDangerScale);
    }

    @Override
    public void onRemoved() {
        super.onRemoved();
        exoticCount--;
    }
}
